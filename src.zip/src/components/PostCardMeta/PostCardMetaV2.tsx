import React from "react";

const PostCardMetaV2 = () => {
  return <div>PostCardMetaV2</div>;
};

export default PostCardMetaV2;
