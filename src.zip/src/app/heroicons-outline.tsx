"use client";

import HeroiconsOutline from "@heroicons/react/24/outline";

export default HeroiconsOutline;
